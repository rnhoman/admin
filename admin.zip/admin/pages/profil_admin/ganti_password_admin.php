<div class="row">
	<div class="col-md-6 col-sm-offset-3">
		<div class="box box-primary">
			<div class="box-header with-border">
				<h3 class="box-title">Ganti Password Admin</h3>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Password Lama</label>
						<input type="text" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Password Baru</label>
						<input type="text" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Ulangi Password Baru</label>
						<input type="" name="" class="form-control">
					</div>
				</form>
			</div>
			<div class="box-footer">
				<button type="submit" class="btn btn-success pull-right" name="" title="Ganti Password"><i class="fa fa-save"></i>&nbsp; GANTI PASSWORD</button>
				<a href="index.php" class="btn btn-danger" title="Batal"><i class="fa fa-close"></i>&nbsp; BATAL</a>
			</div>
		</div>
	</div>
</div>