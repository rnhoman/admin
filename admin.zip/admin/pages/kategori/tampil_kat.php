<?php 
	$nongolindatakategori = $kategori->nongol_kategori();

	if (isset($_GET['id'])) 
	{
		$id_kat = $_GET['id'];
		$kategori->hapus_kategori($id_kat);
		echo "<script>alert('Data Kategori Berhasil Di Hapus');location='index.php?halaman=kategori';</script>";
	}
?>

<div class="box box-info">
	<div class="box-header">
		<h2 class="box-title">TAMPIL DATA KATEGORI SEWA MENYEAWA</h2>
	</div>
	<div class="box-body table-responsive">
		<a href="index.php?halaman=tambah_kat" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; TAMBAH</a><br><br>
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nama Kategori</td>
					<td>Action</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($nongolindatakategori as $key => $value): ?>
					<tr>
						<td><?php echo $key+1; ?></td>
						<td><?php echo $value['nama_kategori']; ?></td>
						<td>
							<a href="index.php?halaman=edit_kat&id=<?php echo $value['id_kat']; ?>" class="btn btn-primary btn-sm" title="Edit"><i class="fa fa-edit"></i></a>
							<a href="index.php?halaman=kategori&id=<?php echo $value['id_kat']; ?>" class="btn btn-danger btn-sm" title="Hapus"><i class="fa fa-trash"></i></a>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>