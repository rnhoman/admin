<?php 
	$nongolindatamember = $akun_member->nongol_akun_member();

	if (isset($_GET['id'])) 
	{
		$id_member = $_GET['id'];
		$akun_member->hapus_akun_member($id_member);

		echo "<script>alert('Data member berhasil di hapus, silahkan dicek kembali');location='index.php?halaman=akun_pencari_member';</script>";
	}
?>

<div class="box box-info">
	<div class="box-header">
		<h2 class="box-title">TAMPIL DATA AKUN MEMBER SEWA MENYEWA</h2>
	</div>
	<div class="box-body table-responsive">
		<a href="index.php?halaman=tambah_akunpencari_member" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; TAMBAH</a><br><br>
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nama Lengkap</td>
					<td>Username</td>
					<td>Email</td>
					<td>Status Member</td>
					<td>Action</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($nongolindatamember as $key => $value): ?>
					<tr>
						<td><?php echo $key+1; ?></td>
						<td><?php echo $value['nama_member']; ?></td>
						<td><?php echo $value['username_member']; ?></td>
						<td><?php echo $value['email_member']; ?></td>
						<td>
							<?php if ($value['status_member']=="Tidak Aktif") 
							{
								echo "<label class='label label-danger'>Tidak Aktif</label>";
							} 
							elseif ($value['status_member']=="Aktif")
							{
								echo "<label class='label label-success'>Aktif</label>";
							}
							?>
						</td>
						<td>
							<a href="index.php?halaman=edit_akunpencari_member&id=<?php echo $value['id_member']; ?>" class="btn btn-primary btn-sm" title="Edit"><i class="fa fa-edit"></i></a>
							<a href="index.php?halaman=akun_pencari_member&id=<?php echo $value['id_member']; ?>" class="btn btn-danger btn-sm" title="Hapus"><i class="fa fa-trash"></i></a>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>