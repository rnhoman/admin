<?php 
	$nongolkecamatan = $kecamatan_sewa->nongol_kecamatan();

	if (isset($_GET['id'])) 
	{
		$id_kecamatan = $_GET['id'];
		$kecamatan_sewa->hapus_kecamatan($id_kecamatan);
		echo "<script>alert('Data Kecamatan Berhasil Di Hapus, Silahkan Cek Kembali');location='index.php?halaman=kecamatan';</script>";
	}

?>
<div class="box box-info">
	<div class="box-header">
		<h2 class="box-title">TAMPIL DATA KABUPATEN DAN KECAMATAN</h2>
	</div>
	<div class="box-body table-responsive">
		<!-- <a href="index.php?halaman=tambah_kecamatanv1" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; Tambah</a><br><br> -->
		<a href="index.php?halaman=tambah_kec" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; Tambah</a><br><br>
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Kabupaten</td>
					<td>Kecamatan</td>
					<td>Aksi</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($nongolkecamatan as $key => $value): ?>
					<tr>
						<td><?php echo $key+1; ?></td>
						<td><?php echo $value['nama_kabupaten']; ?></td>
						<td><?php echo $value['nama_kecamatan']; ?></td>
						<td>
							<a href="index.php?halaman=edit_kecv1&id=<?php echo $value['id_kecamatan']; ?>" class="btn btn-primary btn-sm" title="Edit"><i class="fa fa-edit"></i></a>
							<a href="index.php?halaman=kecamatan&id=<?php echo $value['id_kecamatan']; ?>" class="btn btn-danger btn-sm" title="Hapus"><i class="fa fa-trash"></i></a>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>