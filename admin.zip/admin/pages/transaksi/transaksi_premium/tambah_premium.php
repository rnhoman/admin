<div class="col-md-6 col-sm-offset-3 col-sm-10">
	<div class="box box-info">
		<div class="box-header with-border">
			<h2 class="box-title">Tambah Pembelian Fitur Pop Premium Sewa Menyewa</h2>
		</div>
		<div class="box-body">
			<form method="PSOT">
				<div class="form-group">
					<label>Kode Premium</label>
					<input type="text" name="" class="form-control">
				</div>
				<div class="form-group">
					<label>Nama Owner</label>
					<select class="form-control select21" name="nama_owner">
						<option value="-">-Pilih Owner-</option>
					</select>
				</div>
				<div class="form-group">
					<label>Nama Paket Premium</label>
					<select class="form-control select2" name="nama_paket">
						<option value="-">-Pilih Paket-</option>
					</select>
				</div>
				<div class="row">
					<div class="form-group">
						<div class="col-lg-6">
						<label>Judul Iklan Sewa</label>
							<div class="input-group">
								<span class="input-group-addon">
									<input type="checkbox" />
								</span>
								<input type="text" class="form-control" value="" />
							</div>
							<!-- /input-group -->
						</div>
					</div>
				</div><br>
				<div class="form-group">
					<button type="submit" name="simpan" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i>&nbsp; PESAN PREMIUM</button>
					<a href="index.php?halaman=pembelian_premium" class="btn btn-danger btn-sm"><i class="fa fa-close"></i>&nbsp; BATAL</a>
				</div>	
			</form>
		</div>
	</div>
</div>