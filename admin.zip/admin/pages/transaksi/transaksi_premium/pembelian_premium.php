<div class="box box-info">
	<div class="box-header with-border">
		<h2 class="box-title">Pembelian Fitur Pop Premium Sewa Menyewa</h2>
	</div>
	<div class="box-body table-responsive">
		<a href="index.php?halaman=tambah_premium" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; TAMBAH</a>
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nama Owner</td>
					<td>Durasi Awal Premium</td>
					<td>DUrasi Selesai Premium</td>
					<td>Status Premium</td>
					<td>Action</td>
				</tr>
			</thead>
			<tbody>
				
			</tbody>
		</table>
	</div>
</div>