<?php 
	$data = $subkategori->tampilin_subkategori();

	if (isset($_GET['id'])) 
	{
		$id_subkat = $_GET['id'];
		$subkategori->hapus_subkategori($id_subkat);
		echo "<script>alert('Data Kategori Sub Kategori Berhasil Di Hapus');location='index.php?halaman=subkategori';</script>";
	}
?>
<div class="box box-info">
	<div class="box-header">
		<h2 class="box-title">TAMPIL DATA KATEGORI DAN SUB KATEGORI SEWA MENYEWA</h2>
	</div>
	<div class="box-body">
		<a href="index.php?halaman=tambah_subkat" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; TAMBAH</a><br><br>
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Kategori</td>
					<td>Sub Kategori</td>
					<td>Aksi</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($data as $key => $value): ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $value['nama_kategori']; ?></td>
							<td><?php echo $value['nama_subkategori']; ?></td>
							<td>
								<a href="index.php?halaman=edit_subkat&id=<?php echo $value['id_subkat']; ?>" class="btn btn-primary btn-sm" title="Edit"><i class="fa fa-edit"></i>&nbsp; </a>
								<a href="index.php?halaman=subkategori&id=<?php echo $value['id_subkat']; ?>" class="btn btn-danger btn-sm" title="hapus"><i class="fa fa-trash"></i>&nbsp; </a>
							</td>
						</tr>
					<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>