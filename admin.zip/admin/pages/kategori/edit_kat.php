<?php 
	$id_kat = $_GET['id'];
	$data_kategori = $kategori->ambil_kategori($id_kat);

	// echo "<pre>";
	// print_r($id_kat);
	// echo "</pre>";
?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">EDIT KATEGORI SEWA</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kategori</label>
						<input type="text" name="nama_kategori" class="form-control" placeholder="Nama Kategori Sewa" value="<?php echo $data_kategori['nama_kategori']; ?>"></input>
					</div>
					<button type="submit" name="update" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i>&nbsp; UPDATE</button>
					<a href="index.php?halaman=kategori" class="btn btn-danger btn-sm"><i class="fa fa-save"></i>&nbsp; BATAL</a>
				</form>
				<?php 
					if (isset($_POST['update'])) 
					{
						$hasil = $kategori->edit_kategori($_POST['nama_kategori'], $id_kat);
						if ($hasil == "sukses") 
						{
							echo "<script>alert('Data Kategori Berhasil Di Rubah');</script>";
							echo "<script>location='index.php?halaman=kategori';</script>";
						}
						else
						{
							echo "<script>alert('Data Kategori Gagal Di Rubah');</script>";
							echo "<script>location='index.php?halaman=edit_kat&id=$_GET[id];</script>";
						}
					}
				?>
			</div>
		</div>
	</div>
</div>