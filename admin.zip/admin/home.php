<div class="row">
	<div class="col-md-3 col-sm-6 col-xs-12">
		<div class="info-box">
			<span class="info-box-icon bg-aqua"><i class="fa fa-user"></i></span>
			<div class="info-box-content">
				<span class="info-box-text">NEW OWNER</span>
				<span class="info-box-number">100</span>
			</div>
		</div>
	</div>

	<div class="col-md-3 col-sm-6 col-xs-12">
		<div class="info-box">
			<span class="info-box-icon bg-red"><i class="fa fa-users"></i></span>
			<div class="info-box-content">
				<span class="info-box-text">NEW MEMBER</span>
				<span class="info-box-number">100</span>
			</div>
		</div>
	</div>

	<div class="col-md-3 col-sm-6 col-xs-12">
		<div class="info-box">
			<span class="info-box-icon bg-blue"><i class="fa fa-shopping-cart"></i></span>
			<div class="info-box-content">
				<span class="info-box-text">TRANSAKSI SEWA <br>MENYEWA</span>
				<span class="info-box-number">100</span>
			</div>
		</div>
	</div>

	<div class="col-md-3 col-sm-6 col-xs-12">
		<div class="info-box">
			<span class="info-box-icon bg-yellow"><i class="fa fa-area-chart"></i></span>
			<div class="info-box-content">
				<span class="info-box-text">PASANG IKLAN<br>SEWA MENYEWA</span>
				<span class="info-box-number">100</span>
			</div>
		</div>
	</div>
</div>

<div class="box box-info">
	<div class="box-header with-border">
		<h3 class="box-title">Latest Reservasi Sewa Menyewa</h3>
		<div class="box-tools pull-right">
			<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
			<button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
		</div>
	</div>
	<div class="box-body">
		<div class="table-responsive">
			<table class="table no-margin">
				<thead>
					<tr>
						<td>Order ID</td>
						<td>Nama Iklan Sewa</td>
						<td>Kategori</td>
						<td>Kab/Kec</td>
						<td>Status</td>
					</tr>
				</thead>
				<tbody>
					<tr>
						
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>