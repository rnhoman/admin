<?php 
	$nongolindatapaketpremium = $paket_premium->nongolin_paketpremium();

	if (isset($_GET['id'])) 
	{
		$id_paket_premium = $_GET['id'];
		$paket_premium->hapus_paketpremium($id_paket_premium);
		echo "<script>alert('Data Paket Premium Berhasil Di Hapus, Silhakan Cek Kembali');location='index.php?halaman=paket_premium';</script>";
	}
?>

<div class="box box-info">
	<div class="box-header">
		<h2 class="box-title">TAMBIL DATA PAKET PREMIUM ATAU FITUR POP UP PREMIUM</h2>
	</div>
	<div class="box-body table-responsive">
		<a href="index.php?halaman=tambah_paketpremium" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; TAMBAH</a><br><br>
		<table class="table table-striped table-bordered" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nama Paket</td>
					<td>Durasi Paket</td>
					<td>Harga Paket</td>
					<td>Action</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($nongolindatapaketpremium as $key => $value): ?>
					<tr>
						<td><?php echo $key+1; ?></td>
						<td><?php echo $value['nama_paketpremium']; ?></td>
						<td><?php echo $value['durasi_paketpremium']; ?></td>
						<td><?php echo $value['harga_paketpremium']; ?></td>
						<td>
							<a href="index.php?halaman=edit_paketpremium&id=<?php echo $value['id_paket_premium']; ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i>&nbsp; </a>
							<a href="index.php?halaman=paket_premium&id=<?php echo $value['id_paket_premium']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>&nbsp; </a>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>