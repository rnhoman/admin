<div class="box box-info">
	<div class="box-header with-border">
		<h2 class="box-title">Pembayaran Fitur Pop Premium Sewa Menyewa</h2>
	</div>
	<div class="box-body table-responsive">
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nomor Invoice Premium</td>
					<td>Nama Owner</td>
					<td>Status Pembayaran Premium</td>
					<td>Status Premium</td>
					<td>Action</td>
				</tr>
			</thead>
			<tbody>
				
			</tbody>
		</table>
	</div>
</div>