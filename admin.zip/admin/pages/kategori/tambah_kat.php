<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">TAMBAH KATEGORI SEWA</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kategori</label>
						<input type="text" name="nama_kategori" class="form-control" placeholder="Input Kategori Sewa"></input>
					</div>
					<button type="submit" name="simpan" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i>&nbsp; ADD</button>
					<a href="index.php?halaman=kategori" class="btn btn-danger btn-sm"><i class="fa fa-close"></i>&nbsp; BATAL</a>
				</form>
				<?php 
					if (isset($_POST['simpan'])) 
					{
						$hasil = $kategori->simpan_kategori($_POST['nama_kategori']);
						if ($hasil == "sukses") 
						{
							echo "<script>alert('Data Kategori Sewa Berhasil Disimpan');</script>";
							echo "<script>location='index.php?halaman=kategori';</script>";
						}
						else
						{
							echo "<script>alert('Data Kategori Sewa Sudah Ada, Gagal Disimpan');</script>";
							echo "<script>location='index.php?halaman=tambah_kat';</script>";
						}
					}
				?>
			</div>
		</div>
	</div>
</div>