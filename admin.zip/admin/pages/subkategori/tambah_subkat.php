<?php 
	$data_tampil_kategori = $kategori->nongol_kategori();
?>
<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">TAMBAH SUB KATEGORI SEWA</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kategori</label>
						<select name="nama_kategori" class="form-control">
							<option>-Pilih Kategori-</option>
							<?php foreach ($data_tampil_kategori as $key => $value): ?>
								<option value="<?php echo $value['id_kat']; ?>"><?php echo $value['nama_kategori']; ?></option>
							<?php endforeach ?>
						</select>
					</div>
					<div class="form-group">
						<label>Nama Sub Kategori</label>
						<input type="text" name="nama_subkategori" class="form-control" placeholder="Nama Sub Kategori"></input>
					</div>
					<button type="submit" name="simpan" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i>&nbsp; ADD</button>
					<a href="index.php?halaman=subkategori" class="btn btn-danger btn-sm"><i class="fa fa-close"></i>&nbsp; BATAL</a>
				</form>
				<?php 
					if (isset($_POST['simpan'])) 
					{
						$hasil = $subkategori->simpan_subkategori($_POST['nama_kategori'], $_POST['nama_subkategori']);
						if ($hasil == "sukses") 
						{
							echo "<script>alert('Data Sub Kategori Sewa Berhasil Disimpan');</script>";
							echo "<script>location='index.php?halaman=subkategori';</script>";
						}
						else
						{
							echo "<script>alert('Data Sub Kategori Sewa Sudah Ada, Gagal Disimpan');</script>";
							echo "<script>location='index.php?halaman=tambah_subkat';</script>";
						}
					}
				?>
			</div>
		</div>
	</div>
</div>