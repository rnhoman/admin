<?php 
	$datadiambil = $kabupaten->nongol_kabupaten();
?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">TAMBAH KECAMATAN</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kabupaten</label>
						<select class="form-control" name="nama_kabupaten">
							<option>-Pilih Kabupaten-</option>
							<?php foreach ($datadiambil as $key => $value): ?>
								<option value="<?php echo $value['id_kabupaten']; ?>"><?php echo $value['nama_kabupaten']; ?></option>
							<?php endforeach ?>
						</select>
					</div>
					<div class="form-group">
						<label>Nama Kecamatan</label>
						<input type="text" name="nama_kecamatan" class="form-control" placeholder="Input Kecamatan">
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-success btn-sm pull-right" name="save"><i class="fa fa-save">&nbsp; ADD </i></button>
						<a href="index.php?halaman=kecamatan" class="btn btn-danger btn-sm"><i class="fa fa-close"></i>&nbsp; BATAL</a>
					</div>
				</form>
				<?php 
				if (isset($_POST['save'])) 
				{
					$hasil = $kecamatan_sewa->simpan_kecamatan($_POST['nama_kabupaten'], $_POST
						['nama_kecamatan']);
					if ($hasil == "sukses") 
					{
						echo "<script>alert('Data Kecamatan Berhasil Di Simpan');</script>";
						echo "<script>location='index.php?halaman=kecamatan';</script>";
					}
					else
					{
						echo "<script>alert('Data Kecamatan Gagal Di Simpan');</script>";
						echo "<script>location='index.php?halaman=tambah_kec'</script>";
					}
				}
				?>
			</div>
		</div>
	</div>
</div>