<?php 
	$data_tampil_kabupaten = $kabupaten->nongol_kabupaten();

	$id_kecamatan = $_GET['id'];
	$data_kecamatan = $kecamatan_sewa->ambil_kecamatan($id_kecamatan);

?>


<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title"><i class="fa fa-dashboard"></i>UPDATE KECAMATAN</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kabupaten</label>
						<select name="nama_kabupaten" class="form-control">
							<option>-Pilih Kabupaten-</option>
							<?php foreach ($data_tampil_kabupaten as $key => $value): ?>
								<option value="<?php echo $value['id_kabupaten']; ?>" <?php if ($value['id_kabupaten']==$data_kecamatan['id_kabupaten']) {echo "selected";} ?>><?php echo $value['nama_kabupaten']; ?></option>
							<?php endforeach ?>
						</select>
					</div>
					<div class="form-group">
						<label>Nama Kecamatan</label>
						<input type="text" name="nama_kecamatan" class="form-control" placeholder="Input Kecamatan" value="<?php echo $data_kecamatan['nama_kecamatan']; ?>"></input>
					</div>
					<button type="submit" name="update_kec" class="btn btn-success btn-sm"><i class="fa fa-save"></i>&nbsp; UPDATE</button>
					<a href="index.php?halaman=kecamatan" class="btn btn-danger btn-sm pull-right"><i class="fa fa-close"></i>&nbsp; BATAL</a>
				</form>
				<?php 
				if (isset($_POST['update_kec'])) 
				{
					$hasil = $kecamatan->edit_kecamatan($_POST['nama_kecamatan'],$id_kecamatan);
					if ($hasil == "sukses") 
					{
						echo "<script>alert('Data Kabupaten dan Kecamatan Berhasil Di Update, Silahkan Cek!');</script>";
						echo "<script>location='index.php?halaman=kecamatan';</script>";
					}
					else
					{
						echo "<script>alert('Data Kabupaten dan Kecamatan Sudah Ada, Gagal Di Update');</script>";
						echo "<script>location='index.php?halaman=tambah_kecamatanv1';</script>";
					}
				}
				?>
			</div>
		</div>
	</div>
</div>