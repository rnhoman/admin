<style type="text/css" media="screen">
#map-canvas {        
	height: 500px;
	width: 100%;        
}
.controls {
  margin-top: 10px;
  border: 1px solid transparent;
  border-radius: 2px 0 0 2px;
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  height: 32px;
  outline: none;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
}

#pac-input {
  background-color: #fff;
  font-family: Roboto;
  font-size: 15px;
  font-weight: 300;
  margin-left: 12px;
  padding: 0 11px 0 13px;
  text-overflow: ellipsis;
  width: 300px;
}

#pac-input:focus {
  border-color: #4d90fe;
}

.pac-container {
  font-family: Roboto;
}

#type-selector {
  color: #fff;
  background-color: #4d90fe;
  padding: 5px 11px 0px 11px;
}

#type-selector label {
  font-family: Roboto;
  font-size: 13px;
  font-weight: 300;
}
#target {
  width: 345px;
}
</style>

<div class="box box-primary">
	<div class="box-header">
		<h2 class="box-title">PASANG IKLAN SEWA MENYEWA</h2>
	</div>
	<div class="box-body">
		<form class="form-horizontal" method="POST" enctype="multipart/form-data">
			<div class="form-group">
				<label class="col-sm-3 control-label">Upload Gambar Iklan Utama</label>
				<div class="col-sm-3">
					<input type="file" name="foto_satu" class="form-control" multiple="">
					<img src="" class="" width="100" height="100" onerror="this.src='https://place-hold.it/200'"><br><br>
				</div>
				<div class="col-sm-3">
					<input type="file" name="foto_dua" class="form-control" multiple="">
					<img src="" class="" width="100" height="100"  onerror="this.src='https://place-hold.it/200'"><br><br>
				</div>
				<div class="col-sm-3">
					<input type="file" name="foto_tiga" class="form-control" multiple="">
					<img src="" class="" width="100" height="100" onerror="this.src='https://place-hold.it/200'"><br><br>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Nama Owner</label>
				<div class="col-sm-9">
					<select class="form-control select21" name="nama_owner">
						<?php foreach ($akun_owner->tampilin_akun_owner() as $key => $value): ?>
							<option><?php echo $value['nama_owner']; ?></option>
						<?php endforeach ?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Judul Iklan Sewa</label>
				<div class="col-sm-9">
					<input type="text" name="judul_iklan_sewa" class="form-control">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Nama Kategori</label>
				<div class="col-sm-9">
					<select class="form-control" name="nama_kategori">
						<option>-Pilih Kategori-</option>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Nama Sub Kategori</label>
				<div class="col-sm-9">
					<select class="form-control" name="nama_subkategori">
						<option>-Pilih Sub Kategori-</option>
						<?php 
							// foreach ($tampilin_subkategori as $key => $value) 
							// {
								
							// }
						?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Metode Pembayaran</label>
				<div class="col-sm-9 radio">
					<label><input type="radio" name="metode_pembayaran" value="tf">Transfer &nbsp;</label><br>
					<label><input type="radio" name="metode_pembayaran" value="cod">Bayar Di Tempat (COD)</label>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Harga Sewa</label>
				<div class="col-sm-9">
					<div class="input-group">
						<input type="text" name="enam_jam" class="form-control">
						<span class="input-group-addon">6 Jam</span>
					</div>
					<div class="input-group">
						<input type="text" name="duabelas_jam" class="form-control">
						<span class="input-group-addon">12 Jam</span>
					</div>
					<div class="input-group">
						<input type="text" name="duaempat_jam" class="form-control">
						<span class="input-group-addon">24 Jam</span>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Pendamping Unit Sewa</label>
				<div class="col-sm-9 radio">
					<label><input type="radio" name="pendamping_sewa" value="lepas_kunci">Lepas Kunci &nbsp;</label><br>
					<label><input type="radio" name="pendamping_sewa" value="bersama_supir">Bersama Supir</label><br>
					<label><input type="radio" name="pendamping_sewa" value="bersama_supir">Pilot Drone</label><br>
					<label><input type="radio" name="pendamping_sewa" value="bukan_unit_mobil">Bukan Unit Mobil</label>
					<p class="help-block">*Unit yang tidak bisa boleh dilepas atau tanpa pengawasan seperti mobil, drone</p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Deskripsi Iklan Sewa</label>
				<div class="col-sm-9">
					<textarea class="textarea" name="deskripsi_sewa" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
						
					</textarea>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Fasilitas Sewa</label>
				<div class="col-sm-9">
					<textarea class="textarea" name="fasilitas_sewa" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
						
					</textarea>
				</div>
			</div>
			<div class="form-group" style="margin-bottom: -1em;">
				<h4 class="col-sm-4">Informasi Kontak Sewa Menyewa</h4>
			</div>
			<hr style="border: 1px solid #d2d2d2;">
			<div class="form-group">
				<label class="col-sm-3 control-label">Email</label>
				<div class="col-sm-9">
					<input type="email" name="email_pemilik_sewa" class="form-control">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Nomor Telepon/Hp</label>
				<div class="col-sm-9">
					<input type="text" name="no_tlp_usaha" class="form-control" onkeypress="return hanyaAngka(event)">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Alamat Tempat Sewa</label>
				<div class="col-sm-9">
					<textarea class="form-control" nama="alamat_tmpt_usaha" rows="3" id="autocomplete" onFocus="geolocate()"></textarea>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Kabupaten</label>
				<div class="col-sm-9">
					<select class="form-control" name="nama_kabupaten" id="kabupaten">
						<option>-Pilih Kabupaten-</option>
						<?php foreach ($kabupaten->nongol_kabupaten() as $key => $value): ?>
							<option value="<?php echo $value['id_kabupaten']; ?>" ><?php echo $value['nama_kabupaten']; ?></option>
						<?php endforeach ?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Kecamatan</label>
				<div class="col-sm-9">
					<select class="form-control" name="nama_kecamatan" id="kecamatan">
						<option>-Pilih Kecamatan-</option>
					</select> 
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Titik Koordinat</label>
				<div class="col-sm-9">
					<input id="pac-input" class="controls" type="text" placeholder="Search Box">
	                <div class="gmap" id="map-add" style="width: 100%; height: 250px;"></div>
	                <p>Koordinat: <span id="map-add-latitude"></span>, <span id="map-add-longitude"></span></p>
	                <input type="text" id="map-add-latitude" name="no_lat">
	                <input type="text" id="map-add-longitude" name="no_long">
	                <input type="hidden" id="map-add-hidden_latitude" name="latitude" required>
	                <input type="hidden" id="map-add-hidden_longitude" name="longitude" required>
				</div>
			</div>
			<div class="box-footer">
				<button type="submit" name="simpan" class="btn btn-success"><i class="fa fa-save"></i>&nbsp; SAVE</button>
				<a href="index.php?halaman=pasang_iklan_sewa" class="btn btn-danger pull-right"><i class="fa fa-close"></i>&nbsp; BATAL</a>
			</div>
		</form>
		<?php 
			if (isset($_POST['simpan'])) 
			{
				
			}
		?>
	</div>
</div>
<script src="../../plugins/jQuery/jquery-2.2.3.min.js" type="text/javascript"></script>
<script type="text/javascript">
	
                function initAutocomplete() {
                  // $('#map-add-latitude').text('');
                  // $('#map-add-longitude').text('');
                  $('#map-add-latitude').val('');
                  $('#map-add-longitude').val('');
                  $('#map-add-hidden_latitude').val(null);
                  $('#map-add-hidden_longitude').val(null);
                  var coordinate = {lat: -7.797068, lng: 110.370529};
                  var map = new google.maps.Map(document.getElementById('map-add'), {
                    zoom: 11,
                    center: coordinate
                  });
                  var marker = new google.maps.Marker({
                    position: coordinate,
                    map: map
                  });
                  google.maps.event.addListener(map, 'click', function(event){
                    var latLng = new google.maps.LatLng(event.latLng.lat(), event.latLng.lng());
                    marker.setPosition(latLng);
                    // $('#map-add-latitude').text(event.latLng.lat());
                    // $('#map-add-longitude').text(event.latLng.lng());
                    $('#map-add-latitude').val(event.latLng.lat());
                    $('#map-add-longitude').val(event.latLng.lng());
                    $('#map-add-hidden_latitude').val(event.latLng.lat());
                    $('#map-add-hidden_longitude').val(event.latLng.lng());

                  });
                  // Create the search box and link it to the UI element.
				  var input = document.getElementById('pac-input');
				  var searchBox = new google.maps.places.SearchBox(input);
				  map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);

				  // Bias the SearchBox results towards current map's viewport.
				  map.addListener('bounds_changed', function() {
				    searchBox.setBounds(map.getBounds());
				  });

				  var markers = [];
				  // Listen for the event fired when the user selects a prediction and retrieve
				  // more details for that place.
				  searchBox.addListener('places_changed', function() {
				    var places = searchBox.getPlaces();

				    if (places.length == 0) {
				      return;
				    }

				    
				    // For each place, get the icon, name and location.
				    var bounds = new google.maps.LatLngBounds();
				    places.forEach(function(place) {
				      if (!place.geometry) {
				        console.log("Returned place contains no geometry");
				        return;
				      }

				      if (place.geometry.viewport) {
				        // Only geocodes have viewport.
				        bounds.union(place.geometry.viewport);
				      } else {
				        bounds.extend(place.geometry.location);
				      }
				    });
				    map.fitBounds(bounds);
				  });
                  google.maps.event.addListener(map, 'mousemove', function(event){
                    map.setOptions({draggableCursor: 'pointer'});
                  });
                }

    	$('#kabupaten').change(function() {
    		var id = $('#kabupaten').val();
    		// alert(id);
    	 	$.ajax({
                url: "./pages/pasang_iklan_sewa/getKecamatan.php",
                type: 'POST',
                data: {
                    id: id,
                },
                success: function(data) {
                	// alert(data);
                	var html = '<option> -- silahkan pilih kecamatan -- </option>';
                	if(data == 'null'){
                		alert('data kecamatan tidak ditemukan di kabupaten ini');
                	}
                	else{
	                	data = JSON.parse(data);
	                	console.log(data);
	                	for (var i = data.length - 1; i >= 0; i--) {
	                		html += "<option value="+ data[i].id_kecamatan + ">" + data[i].nama_kecamatan + "</option>";
	                	}
	                	$('#kecamatan').html(html);
                	}                	

                }
            });
    	});
</script>