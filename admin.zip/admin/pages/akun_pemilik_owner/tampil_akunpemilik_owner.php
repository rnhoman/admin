<?php 
	$nongolinakunowner = $akun_owner->tampilin_akun_owner();

	if(isset($_GET['id']))
	{
		$id_owner = $_GET['id'];
		$akun_owner->hapus_akun_owner($id_owner);

		echo "<script>alert('Data owner berhasil di hapus, silahkan dicek');location='index.php?halaman=akun_pemilik_owner';</script>";
	}
?>

<div class="box box-info">
	<div class="box-header">
		<h2 class="box-title">TAMPILAN AKUN OWNER SEWA</h2>
	</div>
	<div class="box-body table-responsive">
		<a href="index.php?halaman=tambah_akunpemilik_owner" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; TAMBAH</a><br><br>
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nama Langkap</td>
					<td>Nomor Tlp/Hp</td>
					<td>Email</td>
					<td>Status Akun</td>
					<td>Action</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($nongolinakunowner as $key => $value): ?>
					<tr>
						<td><?php echo $key+1; ?></td>
						<td><?php echo $value['nama_owner']; ?></td>
						<td><?php echo $value['telp_owner']; ?></td>
						<td><?php echo $value['email_owner']; ?></td>
						<td>
							<?php if ($value['status_owner']=="Tidak Aktif") 
							{
								echo "<label class='label label-danger'>Tidak Aktif</label>";
							} 
							elseif ($value['status_owner']=="Aktif")
							{
								echo "<label class='label label-success'>Aktif</label>";
							}
							?>		
						</td>
						<td>
							<a href="index.php?halaman=edit_akunpemilik_owner&id=<?php echo $value['id_owner']; ?>" class="btn btn-primary btn-sm" title="Edit"><i class="fa fa-edit"></i></a>
							<a href="index.php?halaman=akun_pemilik_owner&id=<?php echo $value['id_owner']; ?>" class="btn btn-danger btn-sm" title="Hapus"><i class="fa fa-edit"></i></a>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>