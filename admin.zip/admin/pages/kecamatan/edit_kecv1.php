<?php 
	$nongolinkabupaten = $kabupaten->nongol_kabupaten();

	$id_kecamatan = $_GET['id'];
	$datakecamatan = $kecamatan_sewa->ambil_kecamatan($id_kecamatan);
	
?>

<div class="box box-primary">
	<div class="box-header">
		<h2 class="box-title">EDIT KECAMATAN</h2>
	</div>
	<div class="box-body">
		<form method="POST">
			<div class="form-group">
				<label>Nama Kabupaten</label>
				<select class="form-control" name="nama_kabupaten">
					<option>-Pilih Kabupatern-</option>
					<?php foreach ($nongolinkabupaten as $key => $value): ?>
						<option value="<?php echo $value['id_kabupaten']; ?>" <?php if ($value['id_kabupaten'] == $datakecamatan['id_kabupaten']) {echo "selected";} ?>> <?php echo $value['nama_kabupaten']; ?></option>
					<?php endforeach ?>
				</select>
			</div>
			<div class="form-group">
				<label>Nama Kecamatan</label>
				<input type="text" name="nama_kecamatan" class="form-control" placeholder="Input Kecamatan" value="<?php echo $datakecamatan['nama_kecamatan']; ?>">
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success btn-sm pull-right" name="update"><i class="fa fa-save"></i>&nbsp; ADD</button>
				<a href="index.php?halaman=kecamatan" class="btn btn-danger btn-sm"><i class="fa fa-close"></i>&nbsp; BATAL</a>
			</div>
		</form>
		<?php 
			if (isset($_POST['update'])) 
			{
				$hasil = $kecamatan_sewa->edit_kecamatan($_POST['nama_kecamatan'],$id_kecamatan);
				if ($hasil == "sukses") 
				{
					echo "<script>alert('Data Kecamatan Berhasil Di Update');</script>";
					echo "<script>location='index.php?halaman=kecamatan';</script>";
				}
				else
				{
					echo "<script>alert('Data Kecamatan Gagal Di Update');</script>";
					echo "<script>location='index.php?halaman=edit_kecv1&id=$_GET[id]';</script>";
				}
			}
		?>
	</div>
</div>
