<?php 
	$datatampilkategori = $kategori->nongol_kategori();

	$id_subkat = $_GET['id'];
	$data_subkategori = $subkategori->ambil_subkategori($id_subkat);
?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">EDIT SUB KATEGORI SEWA</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kategori</label>
						<select name="nama_kategori" class="form-control">
							<option>-Pilih Kategori-</option>
							<?php foreach ($datatampilkategori as $key => $value): ?>
								<option value="<?php echo $value['id_kat']; ?>" <?php if ($value['id_kat']==$data_subkategori['id_kat']) {echo "selected";} ?>><?php echo $value['nama_kategori']; ?></option>
							<?php endforeach ?>
						</select>
					</div>
					<div class="form-group">
						<label>Nama Sub Kategori</label>
						<input type="text" name="nama_subkategori" class="form-control" placeholder="Input Nama Subkategori Sewa" value="<?php echo $data_subkategori['nama_subkategori']; ?>" />
					</div>
					<button type="submit" name="update_subkat" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i>&nbsp; UPDATE</button>
					<a href="index.php?halaman=subkategori" class="btn btn-danger btn-sm"><i class="fa fa-close"></i>&nbsp; BATAL</a>
				</form>
				<?php 
					if (isset($_POST['update_subkat'])) 
					{
						$hasil = $subkategori->edit_subkategori($_POST['nama_subkategori'], $id_subkat);
						if ($hasil == "sukses") 
						{
							echo "<script>alert('Data Sub Kategori Sewa Berhasil Disimpan');</script>";
							echo "<script>location='index.php?halaman=subkategori';</script>";
						}
						else
						{
							echo "<script>alert('Data Sub Kategori Sewa Sudah Ada, Gagal Disimpan');</script>";
							echo "<script>location='index.php?halaman=edit_subkat&id=$_GET[id]';</script>";
						}
					}

					// echo "<pre>";
					// print_r($_POST);
					// echo "</pre>";
				?>
			</div>
		</div>
	</div>
</div>