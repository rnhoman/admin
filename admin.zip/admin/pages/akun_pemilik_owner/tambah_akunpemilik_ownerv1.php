<div class="alert alert-info alert-dismissible">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	<h4><i class="icon fa fa-bullhorn"></i>&nbsp; INFORMASI</h4>
	<ul>
		<li>Harap Melengkapi <b>Data Pribadi Pemilik Tempat Sewa/Owner</b></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
		<li></li>
	</ul>
</div>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">REGISTRASI AKUN OWNER</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Lengkap</label>
						<input type="text" name="nama_lengkap_owner" class="form-control" placeholder="Input Nama Lengkap Owner">
					</div>
					<div class="form-group">
						<label>Nama Tempat Sewa</label>
						<input type="text" name="nama_tempat_sewa" class="form-control" placeholder="Input Nama Tempat Sewa">
					</div>
					<div class="form-group">
						<label>Nomor Tlp/Hp</label>
						<input type="number" name="no_tlp" class="form-control" placeholder="Input Nomor Tlp/Hp">
					</div>
					<div class="form-group">
						<label>Alamat</label>
						<textarea class="form-control" name="alamat_owner" row="4"></textarea>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" name="email_login" class="form-control" placeholder="Input Email">
					</div>
					<div class="form-group">
						<label>Passowrd</label>
						<input type="password" name="password_login" class="form-control" placeholder="Input Password">
					</div>
					<div class="form-group">
						<label>Re-Passowrd</label>
						<input type="password" name="repassword_login" class="form-control" placeholder="Input Re-Password">
					</div>
					<div class="form-group">
						<?php 
						echo "<pre>";
						print_r(tampil_captcha());
						echo "</pre>";
						// $_SESSION['hasil_capca']; 
						?>
						<input type="number" name="jawaban" class="form-control">
					</div>
					<div class="form-group">
						<button type="submit" name="registrasi_owner" class="btn btn-success btn-sm"><i class="fa fa-save"></i>&nbsp; REGISTRASI</button>
						<a href="index.php?halaman=akun_pemilik_owner" class="btn btn-danger btn-sm pull-right"><i class="fa fa-close"></i>&nbsp; BATAL</a>
					</div>
				</form>
				<?php 
				if (isset($_POST['registrasi_owner'])) 
				{
					if ($_POST['password_login']==$_POST['repassword_login']) 
					{
						// echo "<script>alert('Password Anda Sama');</script>";

						if ($_POST['jawaban'] == $_SESSION['hasil_capca']) 
						{
							$hasil = $akun_owner->registrasi_akun_owner($_POST['nama_lengkap_owner'],$_POST['nama_tempat_sewa'],$_POST['no_tlp'], $_POST['alamat_owner'], $_POST['email_login'],$_POST['password_login']);

							echo "<script>alert('Capcha benar');</script>";
							// echo "<script>location='index.php?halaman=tambah_akunpemilik_owner';</script>";

							if ($hasil == "sukses") 
							{
								echo "<script>alert('Selamat Anda Berhasil Mendaftar, Silahkan Cek Email');</script>";
								echo "<script>location='index.php?halaman=akun_pemilik_owner';</script>";
							}
							else
							{
								echo "<script>alert('Email/Password Anda Salah, Silahkan Cek Kembali');</script>";
								echo "<script>location='index.php?halaman=akun_pemilik_owner';</script>";
							}
						}
						else
						{
							echo "<script>alert('Capca Anda Salah, Silahkan Ulangi');</script>";
							echo "<script>location='index.php?halaman=tambah_akunpemilik_owner';</script>";
						}
					}
					else
					{
						echo "<script>alert('Password Anda Tidak Sama');</script>";
						echo "<script>location='index.php?halaman=tambah_akunpemilik_owner';</script>";
					}
				}
				?>
			</div>
		</div>
	</div>
</div>