<div class="row">
	<div class="col-md-6 col-sm-offset-3 col-sm-8">
		<div class="box box-primary">
			<div class="box-header with-border">
				<h3 class="box-title">Konfirmasi Pembayaran Sewa Menyewa</h3>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>ID Pemesan</label>
						<input type="" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Nama Lengkap Pengirim Rekening Penyewa</label>
						<input type="" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Nomor Rekening Penyewa</label>
						<input type="" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Nominal Transfer Penyewa</label>
						<input type="" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Nama Bank Pengirim</label>
						<input type="" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Tgl Transfer</label>
						<input type="date" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Tgl Konfirmasi</label>
						<input type="date" name="" class="form-control">
					</div>
					<div class="form-group">
						<label>Struk Pembayaran</label>
						<input type="file" name="" class="form-control"> <br>
						<img src="" width="100" height="100">
					</div>
				</form>
			</div>
			<div class="box-footer">
				<button type="submit" class="btn btn-success pull-right" title="Konfirmasi"><i class="fa fa-cart-plus"></i>&nbsp; KONFIRMASI</button>
				<button class="btn btn-primary" title="Print Bukti Pembayaran"><i class="fa fa-print"></i>&nbsp; PRINT PEMBAYARAN</button>
			</div>
		</div>
	</div>
</div>