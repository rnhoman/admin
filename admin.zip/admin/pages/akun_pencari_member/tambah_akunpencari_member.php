<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">TAMBAH AKUN PENCARI / MEMBER</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Lengkap</label>
						<input type="text" name="nama_lengkap_member" class="form-control" placeholder="Input Username">
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" name="email_member" class="form-control" placeholder="Input Email">
					</div>
					<div class="form-group">
						<label>Password</label>
						<input type="password" name="password_member" class="form-control" placeholder="Input Password">
					</div>
					<div class="form-group">
						<label>Confirmasi Password</label>
						<input type="password" name="confirmasipassword_member" class="form-control" placeholder="Input Confirmasi Password">
					</div>
					<!-- <div class="form-group">
						<div class="g-recaptcha" data-sitekey="6Lf5ek0UAAAAAImupyDridMfOL3BjPtQ9Vw1jfuL"></div>
					</div> -->
					<div class="form-group">
						<button type="submit" name="registrasi_member" class="btn btn-success pull-right"><i class="fa fa-save"></i>&nbsp; REGISTRASI</button>
						<a href="index.php?halaman=akun_pencari_member" class="btn btn-danger"><i class="fa fa-close"></i>&nbsp; BATAL</a>
					</div>
				</form>
				<?php 
				if (isset($_POST['registrasi_member'])) 
				{
					if ($_POST['password_member'] == $_POST['confirmasipassword_member']) 
					{
						$hasil = $akun_member->registrasi_akun_member($_POST['nama_lengkap_member'],$_POST['email_member'],$_POST['password_member']);

						if ($hasil == "sukses")
						{
							echo "<script>alert('Selamat Anda Berhasil Mendaftar, Silahkan Cek Email');</script>";
							echo "<script>location='index.php?halaman=akun_pencari_member';</script>";
						}
						else
						{
							echo "<script>alert('Email/Password Anda Salah, Silahkan Cek Kembali');</script>";
							echo "<script>location='index.php?halaman=tambah_akunpencari_member';</script>";
						}
					}
					else
					{
						echo "<script>alert('Password tidak cocok, silahkan ulangi');</script>";
						echo "<script>location='index.php?halaman=tambah_akunpencari_member';</script>";
					}
				}
				?>
			</div>
		</div>
	</div>
</div>