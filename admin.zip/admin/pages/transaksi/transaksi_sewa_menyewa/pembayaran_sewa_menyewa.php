<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">PEMBAYARAN SEWA MENYEWA</h3>
	</div>
	<div class="box-body table-responsive">
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nomor Invoice</td>
					<td>Judul Iklan Sewa</td>
					<td>Status Pembayaran</td>
					<td>Action</td>
				</tr>
			</thead>
		</table>
	</div>
</div>