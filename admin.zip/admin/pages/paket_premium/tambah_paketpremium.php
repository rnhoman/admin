<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">TAMBAH PAKET PREMIUM SEWA MENYEWA</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Paket Premium</label>
						<input type="text" name="nama_paketpremium" class="form-control" placeholder="Input Nama Paket Premium">
					</div>
					<div class="form-group">
						<label>Durasi Paket Premium</label>
						<input type="text" name="durasi_paketpremium" class="form-control" placeholder="Input Durasi Paket Premium">
					</div>
					<div class="form-group">
						<label>Harga Paket Premium</label>
						<input type="number" name="harga_paketpremium" class="form-control" placeholder="Input Harga Paket Premium">
					</div>
					<div class="form-group">
						<label>Keterangan Paket Premium</label>
						<textarea class="form-control" name="ket_paketpremium" rows="4"></textarea>
					</div>
					<div>
						<button type="submit" name="submit_paketpremium" class="btn btn-success pull-right"><i class="fa fa-save"></i>&nbsp; SIMPAN</button>
						<a href="index.php?halaman=paket_premium" class="btn btn-danger"><i class="fa fa-close"></i>&nbsp; BATAL</a>
					</div>
				</form>
				<?php 
				if (isset($_POST['submit_paketpremium'])) 
				{
					$hasil = $paket_premium->simpan_paketpremium($_POST['nama_paketpremium'],$_POST['durasi_paketpremium'],$_POST['harga_paketpremium'],$_POST['ket_paketpremium']);

					if ($hasil == "sukses") 
					{
						echo "<script>alert('Data Paket Premium Berhasil Di Simpan');</script>";
						echo "<script>location='index.php?halaman=paket_premium';</script>";
					}
					else
					{
						echo "<script>alert('Data Paket Premium Gagal Di Simpan');</script>";
						echo "<script>location='index.php?halaman=tambah_paketpremium';</script>";
					}
				}
				?>
			</div>
		</div>
	</div>
</div>