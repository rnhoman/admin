<div class="box box-primary">
	<div class="box-header with-border">
		<h3 class="box-title">PEMESANAN SEWA MENYEWA</h3>
	</div>
	<div class="box-body table-responsive">
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nomor Invoice</td>
					<td>Nama Penyewa</td>
					<td>Judul Iklan Sewa</td>
					<td>Durasi Awal</td>
					<td>Durasi Akhir</td>
					<td>Status Sewa</td>
					<td>Action</td>
				</tr>
			</thead>
		</table>
	</div>
</div>