<?php 
	$id_paket_premium = $_GET['id'];
	$datanongol = $paket_premium->ambil_paketpremium($id_paket_premium);
?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">TAMBAH PAKET PREMIUM SEWA MENYEWA</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Paket Premium</label>
						<input type="text" name="nama_paketpremium" class="form-control" placeholder="Input Nama Paket Premium" value="<?php echo $datanongol['nama_paketpremium']; ?>">
					</div>
					<div class="form-group">
						<label>Durasi Paket Premium</label>
						<input type="text" name="durasi_paketpremium" class="form-control" placeholder="Input Durasi Paket Premium" value="<?php echo $datanongol['durasi_paketpremium']; ?>">
					</div>
					<div class="form-group">
						<label>Harga Paket Premium</label>
						<input type="number" name="harga_paketpremium" class="form-control" placeholder="Input Harga Paket Premium" value="<?php echo $datanongol['harga_paketpremium']; ?>">
					</div>
					<div class="form-group">
						<label>Keterangan Paket Premium</label>
						<textarea class="form-control" name="ket_paketpremium" rows="4"><?php echo $datanongol['keterangan_paketpremium']; ?></textarea>
					</div>
					<div>
						<button type="submit" name="update_paketpremium" class="btn btn-success pull-right"><i class="fa fa-save"></i>&nbsp; SIMPAN</button>
						<a href="index.php?halaman=paket_premium" class="btn btn-danger"><i class="fa fa-close"></i>&nbsp; BATAL</a>
					</div>
				</form>
				<?php 
				if (isset($_POST['update_paketpremium'])) 
				{
					$hasil = $paket_premium->edit_paketpremium($_POST['nama_paketpremium'],$_POST['durasi_paketpremium'],$_POST['harga_paketpremium'],$_POST['ket_paketpremium'],$id_paket_premium);

					if ($hasil == "sukses") 
					{
						echo "<script>alert('Data Paket Premium Berhasil Di Simpan');</script>";
						echo "<script>location='index.php?halaman=paket_premium';</script>";
					}
					else
					{
						echo "<script>alert('Data Paket Premium Gagal Di Simpan');</script>";
						echo "<script>location='index.php?halaman=edit_paketpremium&id=$_GET[id]';</script>";
					}
				}

				// echo "<pre>";
				// print_r($_POST);
				// echo "</pre>";
				?>
			</div>
		</div>
	</div>
</div>