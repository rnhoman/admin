<?php 
include '../../../../config/config.php';
$id = $_POST['id'];
if (!isset($id))
	echo "null";
else{
	$kecamatan = $kecamatan_sewa->nongol_kecamatan($id);
	echo json_encode($kecamatan);
}