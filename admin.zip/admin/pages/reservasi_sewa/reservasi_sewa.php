<div class="box box-info">
	<div class="box-header witd-border">
		<h2 class="box-title">TAMPIL DATA RESERVASI SEWA MENYEWA</h2>
	</div>
	<div class="box-body">
		<div class="table-responsive">
			<table class="table table-bordered table-striped" id="example1">
				<thead>
					<tr>
						<td>No</td>
						<td>Order ID</td>
						<td>Nama Pemilik</td>
						<td>Nama Member</td>
						<td>Judul Iklan Sewa</td>
						<td>Kategori</td>
						<td>Status Reservasi</td>
						<td>Action</td>
					</tr>
				</thead>
				<tbody>
					<!-- <tr>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td>
							<a href="#" class="btn btn-danger btn-sm" title="Hapus"><i class="fa fa-trash"></i></a>
							<a href="#" class="btn btn-info btn-sm" title="Lihat"><i class="fa fa-eye"></i></a>
						</td>
					</tr> -->
				</tbody>
			</table>
		</div>
	</div>
</div>