<?php 
	$datatampilkabupaten = $kabupaten->nongol_kabupaten();

	if (isset($_GET['id'])) 
	{
		$id_kabupaten= $_GET['id'];
		$kabupaten->hapus_kabupaten($id_kabupaten);
		echo "<script>alert('Data Kabupaten Berhasil Di Hapus, Silahkan Di Cek Kembali'); location='index.php?halaman=kabupaten';</script>";
	}
?>
<div class="box box-info">
	<div class="box-header">
		<h2 class="box-title">TAMPIL DATA KABUPATEN DAN KECAMATAN</h2>
	</div>
	<div class="box-body table-responsive">
		<a href="index.php?halaman=tambah_kabupaten" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; Tambah</a><br><br>
		<table class="table table-bordered table striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Kabupaten</td>
					<td>Aksi</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($datatampilkabupaten as $key => $value): ?>
					<tr>
						<td><?php echo $key+1; ?></td>
						<td><?php echo $value['nama_kabupaten']; ?></td>
						<td>
							<a href="index.php?halaman=edit_kabupaten&id=<?php echo $value['id_kabupaten']; ?>" class="btn btn-primary btn-sm" title="Edit"><i class="fa fa-edit"></i></a>
							<a href="index.php?halaman=kabupaten&id=<?php echo $value['id_kabupaten']; ?>" class="btn btn-danger btn-sm" title="Hapus"><i class="fa fa-trash"></i></a>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>