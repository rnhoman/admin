<?php 
	$id_pk = $_GET['id'];
	$datapsngiklansewa = $pasang_iklansewa_owner->ambil_pasang_iklansewa_owner($id_pk);

	$detail_kec = $kecamatan_sewa->ambil_kecamatan($datapsngiklansewa['id_kecamatan']);
?>

<div class="box box-primary">
	<div class="box-header">
		<h2 class="box-title">UPDATE PASANG IKLAN SEWA MENYEWA</h2>
	</div>
	<div class="box-body">
		
		<form class="form-horizontal" method="POST" enctype="multipart/form-data">
			<?php
			if (isset($_POST['nama_kabupaten'])) 
			{
				$id_kabupaten = $_POST['nama_kabupaten'];
				$detail_kabupaten = $kabupaten->detail_kabupaten($id_kabupaten);

				$lat_long = array("lat"=> $detail_kabupaten['lat_kabupaten'], "long"=> $detail_kabupaten['long_kabupaten']);
				// echo $_POST['nama_kabupaten'];
			}
			else
			{
				$id_kabupaten = $detail_kec['id_kabupaten'];
				$lat_long = array("lat"=> $datapsngiklansewa['lat_psik'], "long"=> $datapsngiklansewa['long_psik']);
			}

			if (isset($_POST['nama_kategori'])) 
			{
				$id_kategori = $_POST['nama_kategori'];
			}
			else
			{
				$id_kategori = "";
			}

			?>
			
			<div class="form-group" style="margin-bottom: -1em;">
				<h4 class="col-sm-4">Informasi Kontak Sewa Menyewa</h4>
			</div>
			<hr style="border: 1px solid #dedede;">
			<div class="form-group">
				<label class="col-sm-3 control-label">Kabupaten</label>
				<div class="col-sm-9">
					<select class="form-control" name="nama_kabupaten" onchange="submit()">
						<option>-Pilih Kabupaten-</option>
						<?php foreach ($kabupaten->nongol_kabupaten() as $key => $value): ?>
							<option value="<?php echo $value['id_kabupaten']; ?>"
								<?php 
								if ($value['id_kabupaten'] == $id_kabupaten) 
								{
									echo "selected";
								}
								?>
								>
								<?php echo $value['nama_kabupaten']; ?>
								</option>
						<?php endforeach ?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Kecamatan</label>
				<div class="col-sm-9">
					<select class="form-control select21" name="nama_kecamatan">
						<option>-Pilih Kecamatan-</option>
						<?php foreach ($kecamatan_sewa->nongol_kecamatan($id_kecamatan) as $key => $value): ?>
							<option value="<?php echo $value['id_kecamatan']; ?>"
								<?php 
								if ($value['id_kecamatan'] == $datapsngiklansewa['id_kecamatan']) 
								{
									echo "selected";
								}
								?>
								>
								<?php echo $value['nama_kecamatan']; ?></option>
						<?php endforeach ?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Titik Koordinat</label>
				<div class="col-sm-9">
					<p class="help-block">*Titik Koordinat Tempat Sewa Dengan Google Maps</p>
					<div class="hidden">
						<label class="col-xs-1 control-label">Lat:</label>
						<div class="col-xs-5">
							<input type="text" id="lat" name="no_lat" class="form-control" required="">
						</div>
						<label class="col-xs-1 control-label">Long:</label>
						<div class="col-xs-5">
							<input type="text" id="long" name="no_long" class="form-control" required=""><br>
						</div>
					</div>
					<div class="col-xs-12">
						<div id="map-canvas"></div>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Nomor Telepon/Hp</label>
				<div class="col-sm-9">
					<input type="text" name="no_tlp_sewa" class="form-control" onkeypress="return hanyaAngka(event)">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Alamat Tempat Sewa</label>
				<div class="col-sm-9">
					<textarea class="form-control" name="alamat_tmpt_sewa" rows="3"></textarea>
				</div>
			</div>
			
			<div class="form-group" style="margin-bottom: -1em;">
				<h4 class="col-sm-4">Informasi Pasang Iklan Sewa Menyewa</h4>
			</div>
			<hr style="border: 1px solid #dedede;">
			<div class="form-group">
				<label class="col-sm-3 control-label">Nama Owner</label>
				<div class="col-sm-9">
					<select class="form-control select21" name="nama_owner">
						<option></option>
						<?php foreach ($akun_owner->tampilin_akun_owner() as $key => $value): ?>
							<option value="<?php echo $value['id_owner']; ?>"><?php echo $value['nama_owner']; ?></option>
						<?php endforeach ?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Judul Iklan Sewa</label>
				<div class="col-sm-9">
					<input type="text" name="judul_iklan_sewa" class="form-control">
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Nama Kategori</label>
				<div class="col-sm-9">
					<select class="form-control" name="nama_kategori">
						<option>-Pilih Kategori-</option>
						<?php foreach ($kategori->nongol_kategori() as $key => $value): ?>
							<option value="<?php echo $value['id_kat']; ?>"
								<?php 
								if ($value['id_kat'] == $id_kategori) 
								{
									echo "selected";
								}
								?>
								>
								<?php echo $value['nama_kategori']; ?>
							</option>
						<?php endforeach ?>
					</select>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Nama Sub Kategori</label>
				<div class="col-sm-9">
					<input type="text" name="nama_subkategori" class="form-control" placeholder="Input Nama Sub Kategori">
					<!-- <select class="form-control" name="nama_subkategori">
						<option>-Pilih Sub Kategori-</option>
						<?php //foreach ($subkategori->tampilin_subkategori($id_kategori) as $key => $value): ?>
							<option value="<?php //echo $value['id_subkat']; ?>"><?php //echo $value['nama_subkategori']; ?></option>
						<?php //endforeach ?>
					</select> -->
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Metode Pembayaran</label>
				<div class="col-sm-9 radio">
					<label><input type="radio" name="metode_pembayaran" value="Transfer" <?php if ($datapsngiklansewa['metode_pembayaran'] == 'Transfer') {echo "checked";} ?>>Transfer &nbsp;</label><br>
					<label><input type="radio" name="metode_pembayaran" value="Cash On Delivery (COD)" <?php if ($datapsngiklansewa['metode_pembayaran'] == 'Cash On Delivery (COD)') {echo "checked";} ?>>Cash On Delivery (COD)</label>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Harga Sewa</label>
				<div class="col-sm-9">
					<div class="input-group">
						<input type="text" name="enam_jam" class="form-control">
						<span class="input-group-addon">6 Jam</span>
					</div>
					<div class="input-group">
						<input type="text" name="duabelas_jam" class="form-control">
						<span class="input-group-addon">12 Jam</span>
					</div>
					<div class="input-group">
						<input type="text" name="duaempat_jam" class="form-control">
						<span class="input-group-addon">24 Jam</span>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Pendamping Unit Sewa</label>
				<div class="col-sm-9 radio">
					<label><input type="radio" name="pendamping_sewa" value="Lepas Kunci">Lepas Kunci &nbsp;</label><br>
					<label><input type="radio" name="pendamping_sewa" value="Bersama Supir">Bersama Supir</label><br>
					<label><input type="radio" name="pendamping_sewa" value="Bersama Pilot Drone">Pilot Drone</label><br>
					<label><input type="radio" name="pendamping_sewa" value="Tidak Semua">Tidak Semua</label>
					<p class="help-block">*Silahkan untuk memilih salah satu, jika tidak menggunakan pendamping sewa, maka pilih tidak semua.</p>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Deskripsi Iklan Sewa</label>
				<div class="col-sm-9">
					<textarea class="textarea" name="deskripsi_sewa" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
						
					</textarea>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Fasilitas Sewa</label>
				<div class="col-sm-9">
					<textarea class="textarea" name="fasilitas_sewa" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;">
						
					</textarea>
				</div>
			</div>
			<div class="form-group">
				<label class="col-sm-3 control-label">Upload Gambar Iklan Utama</label>
				<div class="col-sm-3">
					<input type="file" name="foto[]" class="form-control" multiple="">
					<img src="../../images/ps-img/pasang_iklan_sewa/<?php echo $datapsngiklansewa['foto_1']; ?>" class="" width="100" height="100"><br><br>
				</div>
				<div class="col-sm-3">
					<input type="file" name="foto[]" class="form-control" multiple="">
					<img src="" class="" width="100" height="100"><br><br>
				</div>
				<div class="col-sm-3">
					<input type="file" name="foto[]" class="form-control" multiple="">
					<img src="" class="" width="100" height="100"><br><br>
				</div>
			</div>
			<div class="box-footer">
				<button type="submit" name="update" class="btn btn-success"><i class="fa fa-save"></i>&nbsp; SAVE</button>
				<a href="index.php?halaman=pasang_iklan_sewa" class="btn btn-danger pull-right"><i class="fa fa-close"></i>&nbsp; BATAL</a>
			</div>
		</form>
		<?php 
		if (isset($_POST['update'])) 
		{
			$idpk = $pasang_iklansewa_owner->simpan_pasang_iklan_owner($_POST['nama_kecamatan'],$_POST['no_lat'],$_POST['no_long'],$_POST['no_tlp_sewa'],$_POST['alamat_tmpt_sewa'],$_POST['nama_owner'],$_POST['nama_subkategori'],$_POST['judul_iklan_sewa'],$_POST['metode_pembayaran'],$_POST['enam_jam'],$_POST['duabelas_jam'],$_POST['duaempat_jam'],$_POST['fasilitas_sewa'],$_POST['pendamping_sewa'],$_POST['deskripsi_sewa'],$id_pk);

			$img = $_FILES['foto'];

			if (!empty($img)) 
			{
				$img_desc = ubah_bentuk_array_foto($img);

				foreach ($img_desc as $key => $val) 
				{
					if (!empty($val['tmp_name'])) 
					{
						$no = $key+1;
						$pasang_iklansewa_owner->simpan_foto_pasangiklan($val['name'],$val['tmp_name'],$idpk,$no);
					}
				}
			}

			// if ($idpk && $img == "sukses") 
			// {
			// 	echo "<script>alert('Berhasil di posting, silahkan di cek');</script>";
			// 	echo "<script>location='index.php?halaman=pasang_iklan_sewa';</script>";
			// }
			// else
			// {
			// 	echo "<script>alert('Gagal di posting, silahkan di cek kembali');</script>";
			// 	echo "<script>location='index.php?halaman=tmbh_psik';</script>";
			// }
			
		}
		?>
	</div>
</div>