<?php 
	// $tada = $psng_iklan_sewa->tam_psng_iklan_sewa();
	$tada = $pasang_iklansewa_owner->tampilin_pasang_iklansewa_owner();

	if (isset($_GET['id'])) 
	{
		$id_pk = $_GET['id'];
		$pasang_iklansewa_owner->hapus_pasang_iklansewa_owner($id_pk);
		echo "<script>alert('Data Pasang Iklan Sewa Berhasil Di Hapus, Silahkan Cek');location='index.php?halaman=pasang_iklan_sewa';</script>";
	}
	// echo "<pre>";
	// echo print_r($tada);
	// echo "</pre>";
?>

<div class="box box-info">
	<div class="box-header">
		<h2 class="box-title">TAMPILAN DATA PASANG IKLAN SEWA MENYEWA</h2>
	</div>
	<div class="box-body table-responsive">
		<a href="index.php?halaman=tmbh_psik_v2" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; TAMBAH</a><br><br>
		<a href="index.php?halaman=tmbh_psik" class="btn btn-primary btn-sm pull-right"><i class="fa fa-plus"></i>&nbsp; TAMBAH</a><br><br>
		<table class="table table-bordered table-striped" id="example1">
			<thead>
				<tr>
					<td>No</td>
					<td>Nama Owner</td>
					<td>Nama Iklan</td>
					<td>No Hp Tempat sewa</td>
					<td>Harga 6 Jam</td>
					<td>Harga 12 Jam</td>
					<td>Harga 24 Jam</td>
					<!-- <td>Kab/Kec</td> -->
					<td>Action</td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($tada as $key => $value): ?>
					<tr>
						<td><?php echo $key+1; ?></td>
						<td><?php echo $value['nama_owner']; ?></td>
						<td><?php echo $value['judul_penyewa']; ?></td>
						<td><?php echo $value['tlp_usaha']; ?></td>
						<td><?php echo number_format($value['enam_jam']); ?></td>
						<td><?php echo number_format($value['duabelas_jam']); ?></td>
						<td><?php echo number_format($value['duaempat_jam']); ?></td>
						<!-- <td><?php //echo $value['nama_kabupaten']."/".$value['nama_kecamatan']; ?></td> -->
						<td>
							<a href="index.php?halaman=edit_pasang_iklan_sewa&id=<?php echo $value['id_pk']; ?>" class="btn btn-primary btn-xs" title="Edit"><i class="fa fa-edit"></i></a>
							<a href="index.php?halaman=pasang_iklan_sewa&id=<?php echo $value['id_pk']; ?>" class="btn btn-danger btn-xs" title="Hapus"><i class="fa fa-trash"></i></a>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
</div>