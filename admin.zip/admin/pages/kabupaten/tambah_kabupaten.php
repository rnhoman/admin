<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">TAMBAH KABUPATEN</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kabupaten</label>
						<input type="text" name="nama_kabupaten_sewa" class="form-control" placeholder="Input Kabupaten" />
					</div>
					<div class="form-group">
						<label>Lat Kabupaten</label>
						<input type="text" name="lat_kabupaten" class="form-control" placeholder="example : -7.293874">
					</div>
					<div class="form-group">
						<label>Long Kabupaten</label>
						<input type="text" name="long_kabupaten" class="form-control" placeholder="example: 10.94893">
					</div>
					<div class="form-group">
						<button type="submit" name="simpan_kab" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i>&nbsp; SIMPAN</button>
					</div>
				</form>
				<?php 
				if (isset($_POST['simpan_kab'])) 
				{
					$hasil = $kabupaten->simpan_kabupaten($_POST['nama_kabupaten_sewa'],$_POST['lat_kabupaten'],$_POST['long_kabupaten']);
					if ($hasil=="sukses") 
					{
						echo "<script>alert('Data Kabupaten Berhasil Di Simpan');</script>";
						echo "<script>location='index.php?halaman=kabupaten';</script>";
					}
					else
					{
						echo "<script>alert('Data Kabupaten Gagal Di Simpan');</script>";
						echo "<script>location='index.php?halaman=tambah_kabupaten';</script>";
					}
				}
				?>
			</div>
		</div>
	</div>
</div>