<?php 
include '../../config/config.php';
include '../../plugins/phpmailer/PHPMailerAutoload.php';
  // if (!isset($_SESSION['pihak_jasa'])) 
  // {
  //   echo "<script>location='../login.php';</script>";
  // }
?>

<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Administrator Sewa Menyewa</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">

  <link rel="stylesheet" href="dist/css/skins/skin-blue.min.css">
  <!-- css tables -->
  <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
  


  <style>
  #map-canvas {        
    height: 500px;
    width: 100%;        
  }
</style>


</head>

<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">

    <!-- Main Header -->
    <header class="main-header">

      <!-- Logo -->
      <a href="index2.html" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>A</b>SM</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>Administrator </b>SEWA</span>
      </a>

      <!-- Header Navbar -->
      <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
          <ul class="nav navbar-nav">
            <!-- Messages: style can be found in dropdown.less-->
            <li class="dropdown messages-menu">
              <!-- Menu toggle button -->
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-envelope-o"></i>
                <span class="label label-success">4</span>
              </a>
              <ul class="dropdown-menu">
                <li class="header">You have 4 messages</li>
                <li>
                  <!-- inner menu: contains the messages -->
                  <ul class="menu">
                    <li><!-- start message -->
                      <a href="#">
                        <div class="pull-left">
                          <!-- User Image -->
                          <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                        </div>
                        <!-- Message title and timestamp -->
                        <h4>
                          Support Team
                          <small><i class="fa fa-clock-o"></i> 5 mins</small>
                        </h4>
                        <!-- The message -->
                        <p>Why not buy a new awesome theme?</p>
                      </a>
                    </li>
                    <!-- end message -->
                  </ul>
                  <!-- /.menu -->
                </li>
                <li class="footer"><a href="#">See All Messages</a></li>
              </ul>
            </li>
            <!-- /.messages-menu -->

            <!-- Notifications Menu -->
            <li class="dropdown notifications-menu">
              <!-- Menu toggle button -->
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-bell-o"></i>
                <span class="label label-warning">10</span>
              </a>
              <ul class="dropdown-menu">
                <li class="header">You have 10 notifications</li>
                <li>
                  <!-- Inner Menu: contains the notifications -->
                  <ul class="menu">
                    <li><!-- start notification -->
                      <a href="#">
                        <i class="fa fa-users text-aqua"></i> 5 new members joined today
                      </a>
                    </li>
                    <!-- end notification -->
                  </ul>
                </li>
                <li class="footer"><a href="#">View all</a></li>
              </ul>
            </li>
            <!-- Tasks Menu -->
            <li class="dropdown tasks-menu">
              <!-- Menu Toggle Button -->
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-flag-o"></i>
                <span class="label label-danger">9</span>
              </a>
              <ul class="dropdown-menu">
                <li class="header">You have 9 tasks</li>
                <li>
                  <!-- Inner menu: contains the tasks -->
                  <ul class="menu">
                    <li><!-- Task item -->
                      <a href="#">
                        <!-- Task title and progress text -->
                        <h3>
                          Design some buttons
                          <small class="pull-right">20%</small>
                        </h3>
                        <!-- The progress bar -->
                        <div class="progress xs">
                          <!-- Change the css width attribute to simulate progress -->
                          <div class="progress-bar progress-bar-aqua" style="width: 20%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                            <span class="sr-only">20% Complete</span>
                          </div>
                        </div>
                      </a>
                    </li>
                    <!-- end task item -->
                  </ul>
                </li>
                <li class="footer">
                  <a href="#">View all tasks</a>
                </li>
              </ul>
            </li>
            <!-- User Account Menu -->
            <li class="dropdown user user-menu">
              <!-- Menu Toggle Button -->
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <!-- The user image in the navbar-->
                <img src="dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
                <!-- hidden-xs hides the username on small devices so only the image appears. -->
                <span class="hidden-xs">Alexander Pierce</span>
              </a>
              <ul class="dropdown-menu">
                <!-- The user image in the menu -->
                <li class="user-header">
                  <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">

                  <p>
                    Alexander Pierce - Web Developer
                    <small>Member since Nov. 2012</small>
                  </p>
                </li>

                <!-- Menu Footer-->
                <li class="user-footer">
                  <div class="pull-left">
                    <a href="index.php?halaman=ganti_password_admin" class="btn btn-default btn-flat">Ganti Password</a>
                  </div>
                  <div class="pull-right">
                    <a href="#" class="btn btn-default btn-flat">Sign out</a>
                  </div>
                </li>
              </ul>
            </li>
            <!-- Control Sidebar Toggle Button -->
            <li>
              <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">

      <!-- sidebar: style can be found in sidebar.less -->
      <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
          <div class="pull-left image">
            <img src="dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
          </div>
          <div class="pull-left info">
            <p>Alexander Pierce</p>
            <!-- Status -->
            <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
          </div>
        </div>

        <!-- search form (Optional) -->
        <form action="#" method="get" class="sidebar-form">
          <div class="input-group">
            <input type="text" name="q" class="form-control" placeholder="Search...">
            <span class="input-group-btn">
              <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
              </button>
            </span>
          </div>
        </form>
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu">
          <li class="header">HEADER</li>
          <!-- Optionally, you can add icons to the links -->
          <li class="<?php if (!isset($_GET['halaman'])) {echo "active"; } ?>"><a href="index.php"><i class="fa fa-home"></i>&nbsp; <span>Home</span></a></li>
          <li class="treeview <?php /*Data Pemilik Owner*/ if ($_GET['halaman']=="akun_pemilik_owner") {echo "active";} elseif ($_GET['halaman']=="tambah_akunpemilik_owner") {echo "active";} elseif ($_GET['halaman']=="edit_akunpemilik_owner") {echo "active";} /*Data Pencari Member*/ elseif ($_GET['halaman']=="akun_pencari_member") {echo "active";} elseif ($_GET['halaman']=="tampil_akunpencari_member") {echo "active";} elseif ($_GET['halaman']=="tambah_akunpencari_member") {echo "active";} elseif ($_GET['halaman']=="edit_akunpencari_member") {echo "active";} /*Kabupaten*/ elseif ($_GET['halaman']=="kabupaten") {echo "active";} elseif ($_GET['halaman']=="tambah_kabupaten") {echo "active"; } elseif ($_GET['halaman']=="edit_kabupaten") {echo "active";} /*Kategori Jasa Sewa*/ elseif ($_GET['halaman']=="kategori") {echo "active";} elseif ($_GET['halaman']=="tambah_kat") {echo "active";} elseif ($_GET['halaman']=="edit_kat") {echo "active";} /*Sub Kategori Jasa Sewa*/ elseif ($_GET['halaman']=="subkategori") {echo "active";} elseif ($_GET['halaman']=="tambah_subkat") {echo "active";} elseif ($_GET['halaman']=="edit_subkat") {echo "active";} /*Jenis Sewa*/ elseif ($_GET['halaman']=="jenis_sewa") {echo "active";} elseif ($_GET['halaman']=="tambah_jenis_sewa") {echo "active";} elseif ($_GET['halaman']=="edit_jenis_sewa") {echo "active";} /*Kecamtan*/ elseif ($_GET['halaman']=="kecamatan") {echo "active";} elseif ($_GET['halaman']=="tambah_kec") {echo "active";} elseif ($_GET['halaman']=="edit_kec") {echo "active";} /*Paket Premium*/ elseif ($_GET['halaman']=="paket_premium") {echo "active";} elseif ($_GET['halaman']=="tambah_paketpremium") {echo "active";} elseif ($_GET['halaman']=="edit_paketpremium") {echo "active";} ?>">
            <a href="#"><i class="fa fa-cube"></i>&nbsp; <span>Data Master</span> <i class="pull-right fa fa-angle-down"></i></a>
            <ul class="treeview-menu">
              <li class="<?php if ($_GET['halaman']=="akun_pemilik_owner") {echo "active";} elseif ($_GET['halaman']=="tambah_akunpemilik_owner") {echo "active";} elseif ($_GET['halaman']=="edit_akunpemilik_owner") {echo "active";} ?>"><a href="index.php?halaman=akun_pemilik_owner"><i class="fa fa-circle-o"></i>&nbsp; Data Owner</a></li>
              <li class="<?php if ($_GET['halaman']=="akun_pencari_member") {echo "active";} elseif ($_GET['halaman']=="tampil_akunpencari_member") {echo "active";} elseif ($_GET['halaman']=="tambah_akunpencari_member") {echo "active";} elseif ($_GET['halaman']=="edit_akunpencari_member") {echo "active";} ?>"><a href="index.php?halaman=akun_pencari_member"><i class="fa fa-circle-o"></i>&nbsp; Data Member</a></li>
              <li class="<?php if ($_GET['halaman']=="kabupaten") {echo "active";} elseif ($_GET['halaman'] == "tambah_kabupaten") {echo "active"; } elseif ($_GET['halaman']=="edit_kabupaten") {echo "active";} ?>"><a href="index.php?halaman=kabupaten"><i class="fa fa-circle-o"></i>&nbsp; Kabupaten</a></li>
              <li class="<?php if ($_GET['halaman']=="kecamatan") {echo "active";} elseif ($_GET['halaman']=="tambah_kec") {echo "active";} elseif ($_GET['halaman']=="edit_kec") {echo "active";} ?>"><a href="index.php?halaman=kecamatan"><i class="fa fa-circle-o"></i>&nbsp; Kecamatan</a></li>
              <li class="<?php if ($_GET['halaman']=="kategori") {echo "active";} elseif ($_GET['halaman']=="tambah_kat") {echo "active";} elseif ($_GET['halaman']=="edit_kat") {echo "active";} ?>"><a href="index.php?halaman=kategori"><i class="fa fa-circle-o"></i>&nbsp; Kategori</a></li>
              <li class="<?php if ($_GET['halaman']=="subkategori") {echo "active";} elseif ($_GET['halaman']=="tambah_subkat") {echo "active";} elseif ($_GET['halaman']=="edit_subkat") {echo "active";} ?>"><a href="index.php?halaman=subkategori"><i class="fa fa-circle-o"></i>&nbsp; Sub Kategori</a></li>
              <li class="<?php if ($_GET['halaman']=="paket_premium") {echo "active";} elseif ($_GET['halaman']=="tambah_paketpremium") {echo "active";} elseif ($_GET['halaman']=="edit_paketpremium") {echo "active";} ?>"><a href="index.php?halaman=paket_premium"><i class="fa fa-circle-o"></i>&nbsp; Paket Premium</a></li>
              <!-- <li class="<?php /*if ($_GET['halaman']=="jenis_sewa") {echo "active";} elseif ($_GET['halaman']=="tambah_jenis_sewa") {echo "active";} elseif ($_GET['halaman']=="edit_jenis_sewa") {echo "active";}*/ ?>"><a href="index.php?halaman=jenis_sewa"><i class="fa fa-circle-o"></i>&nbsp; Jenis Sewa</a></li> -->
            </ul>
          </li>
          <li class="<?php if ($_GET['halaman']=="pasang_iklan_sewa") {echo "active";} elseif ($_GET['halaman']=="tambah_pasang_iklan_sewa") {echo "active";} elseif($_GET['halaman']=="edit_pasang_iklan_sewa") {echo "active";} elseif ($_GET['halaman']=="read_pasang_iklan_sewa") {echo "active";} ?>"><a href="index.php?halaman=pasang_iklan_sewa"><i class="fa fa-folder-open"></i>&nbsp; <span>Pasang Iklan Sewa</span></a></li>
          <li class="<?php if ($_GET['halaman']=="reservasi_sewa") {echo "active";} elseif ($_GET['halaman']=="read_reservasi_sewa") {echo "active";} ?>"><a href="index.php?halaman=reservasi_sewa"><i class="fa fa-cart-plus"></i>&nbsp; <span>Reservasi</span></a></li>
          <li class="treeview <?php /*konfirmasi_sewa_menyewa*/ if ($_GET['halaman']=="konfirmasi_sewa_menyewa") {echo "active";} elseif ($_GET['halaman']=="pembayaran_sewa_menyewa") {echo "active";} elseif ($_GET['halaman']=="transaksi_sewa_menyewa") {echo "active";} ?>">
            <a href="#"><i class="fa fa-credit-card-alt"></i>&nbsp; <span>Transaksi Sewa</span> <i class="pull-right fa fa-angle-down"></i></a>
            <ul class="treeview-menu">
              <li class="<?php if ($_GET['halaman']=="konfirmasi_sewa_menyewa") {echo "active";} ?>"><a href="index.php?halaman=konfirmasi_sewa_menyewa"><i class="fa fa-circle-o"></i>&nbsp; <span>Konfirmasi Sewa</span></a></li>
              <li class="<?php if ($_GET['halaman']=="pembayaran_sewa_menyewa") {echo "active";} ?>"><a href="index.php?halaman=pembayaran_sewa_menyewa"><i class="fa fa-circle-o"></i>&nbsp; <span>Pembayaran Sewa</span></a></li>
              <li class="<?php if ($_GET['halaman']=="transaksi_sewa_menyewa") {echo "active";} ?>"><a href="index.php?halaman=transaksi_sewa_menyewa"><i class="fa fa-circle-o"></i>&nbsp; <span>Pemesanan Sewa</span></a></li>
            </ul>
          </li>
          <li class="treeview <?php /*Pembelian Premium*/ if ($_GET['halaman']=="pembelian_premium") {echo "active";} elseif ($_GET['halaman']=="tambah_premium") {echo "active";} elseif ($_GET['halaman']=="konfirmasi_pembayaran_premium") {echo "active";} /*Pembayaran Premium*/ elseif ($_GET['halaman']=="pembayaran_premium") {echo "active";} ?>">
            <a href="#"><i class="fa fa-opencart"></i>&nbsp; <span>Fitur Pop Up Premium</span> <i class="pull-right fa fa-angle-down"></i></a>
            <ul class="treeview-menu">
              <li class="<?php if ($_GET['halaman']=="pembelian_premium") {echo "active";} elseif ($_GET['halaman']=="tambah_premium") {echo "active";} ?>"><a href="index.php?halaman=pembelian_premium"><i class="fa fa-circle-o"></i>&nbsp; <span>Pembelian Premium</span></a></li>
              <li class="<?php if ($_GET['halaman']=="pembayaran_premium") {echo "active";} elseif ($_GET['halaman']=="konfirmasi_pembayaran_premium") {echo "active";} ?>"><a href="index.php?halaman=pembayaran_premium"><i class="fa fa-circle-o"></i>&nbsp; <span>Pembayaran Premium</span></a></li>
            </ul>
          </li>
          <!-- <li><a href="#">Home</a></li> -->
          <!-- <li class="treeview <?php //if ($_GET['halaman']=="profil") {echo "active";} elseif ($_GET['halaman']=="edit_profil") {echo "active";} elseif ($_GET['halaman']=="ganti_password") {echo "active";} ?>">
            <a href="#"><i class="fa fa-gear"></i>&nbsp; <span>Pengaturan</span> <i class="pull-right fa fa-angle-down"></i></a>
            <ul class="treeview-menu">
              <li class="<?php //if ($_GET['halaman']=="edit_profil") {echo "active";} ?>"><a href="index.php?halaman=edit_profil"><i class="fa fa-circle-o"></i>&nbsp; <span>Ubah Profil</span></a></li>
              <li class="<?php //if ($_GET['halaman']=="ganti_password") {echo "active";} ?>"><a href="index.php?halaman=ganti_password"><i class="fa fa-circle-o"></i>&nbsp; <span>Ubah Password</span></a></li>
            </ul>
          </li> -->
        </ul>
        <!-- /.sidebar-menu -->
      </section>
      <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          Page Header
          <small>Optional description</small>
        </h1>
        <ol class="breadcrumb">
          <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
          <li class="active">Here</li>
        </ol>
      </section>

      <!-- Main content -->
      <section class="content">
        <?php 
        if (!isset($_GET['halaman'])) 
        {
          include 'home.php';
        }
          // MENU DATA MASTER
          // SUB MENU KABUPATEN
        elseif ($_GET['halaman'] == "kabupaten")
        {
          include 'pages/kabupaten/tampil_kabupaten.php';
        }
        elseif ($_GET['halaman'] == "tambah_kabupaten")
        {
          include 'pages/kabupaten/tambah_kabupaten.php';
        }
        elseif ($_GET['halaman'] == "edit_kabupaten")
        {
          include 'pages/kabupaten/edit_kabupaten.php';
        }
          //SUB MENU KATEGORI
        elseif ($_GET['halaman'] == "kategori")
        {
          include 'pages/kategori/tampil_kat.php';
        }
        elseif ($_GET['halaman'] == "tambah_kat")
        {
          include 'pages/kategori/tambah_kat.php';
        }
        elseif ($_GET['halaman'] == "edit_kat")
        {
          include 'pages/kategori/edit_kat.php';
        }
          //SUB MENU SUB KATEGORI
        elseif ($_GET['halaman'] == "subkategori")
        {
          include 'pages/subkategori/tampil_subkat.php';
        }
        elseif ($_GET['halaman'] == "tambah_subkat")
        {
          include 'pages/subkategori/tambah_subkat.php';
        }
        elseif ($_GET['halaman'] == "edit_subkat") 
        {
          include 'pages/subkategori/edit_subkat.php';
        }
          //RENCANA SUB MENU JENIS SEWA //<<== BELUM TENTU DIGUNAKAN
        elseif ($_GET['halaman'] == "jenis_sewa")
        {
          include 'pages/jenis_sewa/tampil_jenis_sewa.php';
        }
        elseif ($_GET['halaman'] == "tambah_jenis_sewa") 
        {
          include 'pages/jenis_sewa/tambah_jenis_sewa.php';
        }
        elseif ($_GET['halaman'] == "edit_jenis_sewa") 
        {
          include 'pages/jenis_sewa/edit_jenis_sewa.php';
        }
          //SUB MENU KECAMATAN
        elseif ($_GET['halaman'] == "kecamatan") 
        {
          include 'pages/kecamatan/tampil_kec.php';
        }
        elseif ($_GET['halaman'] == "tambah_kec") 
        {
          include 'pages/kecamatan/tambah_kec.php';
        }
        elseif ($_GET['halaman'] == "tambah_kecamatanv1")
        {
          include 'pages/kecamatan/tambah_kecamatanv1.php';
        }
        elseif ($_GET['halaman'] == "edit_kec") 
        {
          include 'pages/kecamatan/edit_kec.php';
        }
        elseif ($_GET['halaman'] == "edit_kecv1")
        {
          include 'pages/kecamatan/edit_kecv1.php';
        }
        /*SUB MENU PAKET PREMIUM*/
        elseif ($_GET['halaman'] == "paket_premium") 
        {
          include 'pages/paket_premium/tampil_paketpremium.php';
        }
        elseif ($_GET['halaman'] == "tambah_paketpremium") 
        {
          include 'pages/paket_premium/tambah_paketpremium.php';
        }
        elseif ($_GET['halaman'] == "edit_paketpremium") 
        {
          include 'pages/paket_premium/edit_paketpremium.php';
        }

          //MENU AKUN SEWA MENYEWA
          //MENU AKUN PEMILIK SEWA / OWNER
        elseif ($_GET['halaman'] == "akun_pemilik_owner")
        {
          include 'pages/akun_pemilik_owner/tampil_akunpemilik_owner.php';
        }
        elseif ($_GET['halaman'] == "edit_akunpemilik_owner") 
        {
          include 'pages/akun_pemilik_owner/edit_akunpemilik_owner.php';
        }
        elseif ($_GET['halaman'] == "tambah_akunpemilik_owner") 
        {
          include 'pages/akun_pemilik_owner/tambah_akunpemilik_owner.php';
        }
        elseif ($_GET['halaman'] == "tambah_akunpemilik_ownerv1") 
        {
          include 'pages/akun_pemilik_owner/tambah_akunpemilik_ownerv1.php';
        }
          // MENU AKUN PENCARI SEWA / MEMBER
        elseif ($_GET['halaman'] == "akun_pencari_member") 
        {
          include 'pages/akun_pencari_member/tampil_akunpencari_member.php';
        }
        elseif ($_GET['halaman'] == "tambah_akunpencari_member") 
        {
          include 'pages/akun_pencari_member/tambah_akunpencari_member.php';
        }
        elseif ($_GET['halaman'] == "edit_akunpencari_member") 
        {
          include 'pages/akun_pencari_member/edit_akunpencari_member.php';
        }
          // MENU PASANG IKLAN SEWA
        elseif ($_GET['halaman'] == "pasang_iklan_sewa")
        {
          include 'pages/pasang_iklan_sewa/pasang_iklan_sewa.php';
        }
        elseif ($_GET['halaman'] == "tambah_pasang_iklan_sewa") 
        {
          include 'pages/pasang_iklan_sewa/tambah_pasang_iklan_sewa.php';
        }
        elseif ($_GET['halaman'] == "edit_pasang_iklan_sewa") 
        {
          include 'pages/pasang_iklan_sewa/edit_pasang_iklan_sewa.php';
        }
        elseif ($_GET['halaman'] == "read_pasang_iklan_sewa") 
        {
          include 'pages/pasang_iklan_sewa/read_pasang_iklan_sewa.php';
        }
        elseif ($_GET['halaman'] == "tmbh_psik")
        {
          include 'pages/pasang_iklan_sewa/tmbh_psik.php';
        }
          // MENU RESERVASI SEWA MENYEWA
        elseif ($_GET['halaman'] == "reservasi_sewa") 
        {
          include 'pages/reservasi_sewa/reservasi_sewa.php';
        }
        elseif ($_GET['halaman'] == "read_reservasi_sewa") 
        {
          include 'pages/reservasi_sewa/read_reservasi_sewa.php';
        }
          // MENU FITUR POP UP PREMIUM
        elseif ($_GET['halaman'] == "pembelian_premium") 
        {
          include 'pages/transaksi/transaksi_premium/pembelian_premium.php';
        }
        elseif ($_GET['halaman'] == "tambah_premium")
        {
          include 'pages/transaksi/transaksi_premium/tambah_premium.php';
        }
        elseif ($_GET['halaman'] == "pembayaran_premium")
        {
          include 'pages/transaksi/transaksi_premium/pembayaran_premium.php';
        }
        elseif ($_GET['halaman'] == "konfirmasi_pembayaran_premium")
        {
          include 'pages/transaksi/transaksi_premium/konfirmasi_pembayaran_premium.php';
        }

          // MENU TRANSAKSI
        elseif ($_GET['halaman'] == "transaksi_sewa_menyewa")
        {
          include 'pages/transaksi/transaksi_sewa_menyewa/transaksi_sewa_menyewa.php';
        }
        elseif ($_GET['halaman'] == "konfirmasi_sewa_menyewa") 
        {
          include 'pages/transaksi/transaksi_sewa_menyewa/konfirmasi_sewa_menyewa.php';
        }
        elseif ($_GET['halaman'] == "pembayaran_sewa_menyewa") 
        {
          include 'pages/transaksi/transaksi_sewa_menyewa/pembayaran_sewa_menyewa.php';
        }

          // MENU PROFIL ADMIN
        elseif ($_GET['halaman'] == "profil_admin")
        {
          include 'pages/profil_admin/profil_admin.php';
        }
        elseif ($_GET['halaman'] == "edit_profil") 
        {
          include 'pages/profil_admin/edit_profil_admin.php';
        }
        elseif ($_GET['halaman'] == "ganti_password_admin") 
        {
          include 'pages/profil_admin/ganti_password_admin.php';
        }

        ?>

      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Main Footer -->
    <footer class="main-footer">
      <!-- To the right -->
      <div class="pull-right hidden-xs">
        Anything you want
      </div>
      <!-- Default to the left -->
      <strong>Copyright &copy; 2016 <a href="#">Company</a>.</strong> All rights reserved.
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
      <!-- Create the tabs -->
      <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
        <li class="active"><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
        <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
      </ul>
      <!-- Tab panes -->
      <div class="tab-content">
        <!-- Home tab content -->
        <div class="tab-pane active" id="control-sidebar-home-tab">
          <h3 class="control-sidebar-heading">Recent Activity</h3>
          <ul class="control-sidebar-menu">
            <li>
              <a href="javascript::;">
                <i class="menu-icon fa fa-birthday-cake bg-red"></i>

                <div class="menu-info">
                  <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                  <p>Will be 23 on April 24th</p>
                </div>
              </a>
            </li>
          </ul>
          <!-- /.control-sidebar-menu -->

          <h3 class="control-sidebar-heading">Tasks Progress</h3>
          <ul class="control-sidebar-menu">
            <li>
              <a href="javascript::;">
                <h4 class="control-sidebar-subheading">
                  Custom Template Design
                  <span class="pull-right-container">
                    <span class="label label-danger pull-right">70%</span>
                  </span>
                </h4>

                <div class="progress progress-xxs">
                  <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
                </div>
              </a>
            </li>
          </ul>
          <!-- /.control-sidebar-menu -->

        </div>
        <!-- /.tab-pane -->
        <!-- Stats tab content -->
        <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
        <!-- /.tab-pane -->
        <!-- Settings tab content -->
        <div class="tab-pane" id="control-sidebar-settings-tab">
          <form method="post">
            <h3 class="control-sidebar-heading">General Settings</h3>

            <div class="form-group">
              <label class="control-sidebar-subheading">
                Report panel usage
                <input type="checkbox" class="pull-right" checked>
              </label>

              <p>
                Some information about this general settings option
              </p>
            </div>
            <!-- /.form-group -->
          </form>
        </div>
        <!-- /.tab-pane -->
      </div>
    </aside>
    <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
   immediately after the control sidebar -->
   <div class="control-sidebar-bg"></div>
 </div>
 <!-- ./wrapper -->

 <!-- REQUIRED JS SCRIPTS -->

 <!-- jQuery 2.2.3 -->
 <script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
 <!-- Bootstrap 3.3.6 -->
 <script src="bootstrap/js/bootstrap.min.js"></script>
 <!-- AdminLTE App -->
 <script src="dist/js/app.min.js"></script>

 <script src="plugins/datatables/jquery.dataTables.min.js"></script>
 <script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
 <script>
  $(function () {
    $("#example1").DataTable();
  });
</script>
<script src="https://www.google.com/recaptcha/api.js"></script>
<script>
  function hanyaAngka(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))

      return false;
    return true;
  }
</script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    //bootstrap WYSIHTML5 - text editor
    $(".textarea").wysihtml5();
  });
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDDZoMhKip8ZfjHjZamPS82fZH_TPDDkHU&libraries=places&callback=initAutocomplete" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script>
  $(document).ready(function(){
    $('.select21').select2();
  });
</script>
</body>
</html>