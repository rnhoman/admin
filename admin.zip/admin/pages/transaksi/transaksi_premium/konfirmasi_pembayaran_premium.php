<div class="row">
	<div class="col-md-6 col-sm-offset-3 col-sm-10">
		<div class="box box-info">
			<div class="box-header with-border">
				<h2 class="box-title">Konfirmasi Pembayaran Fitur Pop Premium Sewa Menyewa</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Owner</label>
						<select class="form-control" name="nama_owner">
							<option value=""></option>
						</select>
					</div>
					<div class="form-group">
						<label>Nama Paket Premium</label>
						<select class="form-control" name="">
							<option value=""></option>
						</select>
					</div>
					<div class="form-group">
						<label>Nomor Invoice Premium</label>
						<input type="text" name="no_invoice_premium" class="form-control">
					</div>
					<div class="form-group">
						<label>Nama Lengkap Rekening Pengirim</label>
						<input type="text" name="nama_rek_pengirim" class="form-control">
					</div>
					<div class="form-group">
						<label>Nomor Rekening Pengirim</label>
						<input type="text" name="no_rek_pengirim" class="form-control">
					</div>
					<div class="form-group">
						<label>Nominal</label>
						<div class="input-group">
							<label class="input-group-addon" id="basic-addon1">Rp</label>
							<input type="text" name="nominal" class="form-control" aria-describedby="basic-addon1">
						</div>
					</div>
					<div class="form-group">
						<label>Upload Struk Pembayaran</label>
						<input type="file" name="struk_pembayaran" class="form-control"><br>
						<img src="" height="100" width="100">
					</div>
					<div class="form-group">
						<label>Tgl Transfer</label>
						<input type="date" name="tgl_transfer" class="form-control">
					</div>
					<div class="form-group">
						<label>Tgl Konfirmasi</label>
						<input type="date" name="tgl_konfirmasi" class="form-control">
					</div>
				</form>
			</div>
			<div class="box-footer">
				<button type="submit" name="simpan" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i>&nbsp; KONFIRMASI PEMBAYARAN PREMIUM</button>
				<a href="index.php?halaman=pembayaran_premium" class="btn btn-danger btn-sm"><i class="fa fa-close"></i>&nbsp; BATAL</a>
			</div>
		</div>
	</div>
</div>