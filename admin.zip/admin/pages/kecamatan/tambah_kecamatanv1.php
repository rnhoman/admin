<?php 
	include '../../config/config.php';
	$nongolinkabupaten = $kabupaten_sewa->tampil_kabupaten();
?>

<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">TAMBAH KABUPATEN DAN KECAMATAN</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kabupaten</label>
						<select name="nama_kabupaten_sewa" class="form-control">
							<option>-Pilih Kabupaten-</option>
							<?php foreach ($nongolinkabupaten as $key => $value): ?>
								<option value="<?php echo $value['id_kabupaten']; ?>"><?php echo $value['nama_kabupaten']; ?></option>
							<?php endforeach ?>
						</select>
					</div>
					<div class="form-group">
						<label>Nama Kecamatan</label>
						<input type="text" name="nama_kecamatan_sewa" class="form-control" placeholder="Input Kecamatan" />
					</div>
					<button type="submit" name="simpan_kec" class="btn btn-success btn-sm"><i class="fa fa-save"></i>&nbsp; ADD</button>
					<a href="index.php?halaman=kecamatan" class="btn btn-danger btn-sm pull-right"><i class="fa fa-close"></i>&nbsp; BATAL</a>
				</form>
				<?php 
					if (isset($_POST['simpan_kec'])) 
					{
						$hasil = $kecamatan->simpan_kecamatan($_POST['nama_kabupaten_sewa'], $_POST['nama_kecamatan_sewa']);
						if ($hasil == "sukses") 
						{
							echo "<script>alert('Data Kabupaten dan Kecamatan Berhasil Di Simpan, Silahkan Cek!');</script>";
							echo "<script>location='index.php?halaman=kecamatan';</script>";
						}
						else
						{
							echo "<script>alert('Data Kabupaten dan Kecamatan Gagal Di Simpan, Silahkn Cek Kembali!')</script>";
							echo "<script>localtion='index.php?halaman=tambah_kecamatanv1';</script>";
						}
					}
				?>
			</div>
		</div>
	</div>
</div>