<?php 
	$id_kabupaten = $_GET['id'];
	$data = $kabupaten->ambil_kabupaten($id_kabupaten);
?>
<div class="row">
	<div class="col-md-6 col-md-offset-3">
		<div class="box box-primary">
			<div class="box-header">
				<h2 class="box-title">UPDATE KABUPATEN</h2>
			</div>
			<div class="box-body">
				<form method="POST">
					<div class="form-group">
						<label>Nama Kabupaten</label>
						<input type="text" name="nama_kabupaten_sewa" class="form-control" placeholder="Nama Kabupaten" value="<?php echo $data['nama_kabupaten']; ?>" /> <?php //echo $data['nama_kabupaten_jasa']; ?>
					</div>
					<div class="form-group">
						<label>Lat Kabupaten</label>
						<input type="text" name="lat_kabupaten" class="form-control" placeholder="example : -7.293874" value="<?php echo $data['lat_kabupaten']; ?>">
					</div>
					<div class="form-group">
						<label>Long Kabupaten</label>
						<input type="text" name="long_kabupaten" class="form-control" placeholder="example: 10.94893" value="<?php echo $data['long_kabupaten']; ?>">
					</div>
					<button type="submit" name="update_kab" class="btn btn-success btn-sm pull-right"><i class="fa fa-save"></i>&nbsp; UPDATE</button>
					<a href="index.php?halaman=kabupaten" class="btn btn-danger btn-sm"><i class="fa fa-close"></i>&nbsp; BATAL</a>
				</form>
				<?php 
				if (isset($_POST['update_kab'])) 
				{
					$hasil = $kabupaten->edit_kabupaten($_POST['nama_kabupaten_sewa'],$_POST['lat_kabupaten'],$_POST['long_kabupaten'], $id_kabupaten);
					if ($hasil == "sukses") 
					{
						echo "<script>alert('Data Kabupaten Berhasil Di Update');</script>";
						echo "<script>location='index.php?halaman=kabupaten';</script>";
					}
					else
					{
						echo "<script>alert('Data Kabupaten Sudah Ada, Gagal Di Update');</script>";
						echo "<script>location='index.php?halaman=edit_kabupaten&id=$_GET[id];</script>";
					}
				}
				?>
			</div>
		</div>
	</div>
</div>